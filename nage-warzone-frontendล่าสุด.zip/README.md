# Nage Warzone Frontend

Install dependencies:
```bash
npm install
```

Start development server:
```bash
npm run dev
```

Connects to backend at: https://warzonebackend-3il3.onrender.com